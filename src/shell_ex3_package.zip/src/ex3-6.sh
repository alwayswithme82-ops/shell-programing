#!/bin/bash

if [ $# -lt 2 ]; then
    echo "두 개 이상 인자 필요"
    exit 1
fi

python3 ex3-6.py "$@"

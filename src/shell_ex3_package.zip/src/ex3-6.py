#!/usr/bin/env python3
import sys

print("=== Python 실행 시작 ===")
for i, arg in enumerate(sys.argv[1:], start=1):
    print(f"인자 {i}: {arg}")
print("=== Python 실행 끝 ===")

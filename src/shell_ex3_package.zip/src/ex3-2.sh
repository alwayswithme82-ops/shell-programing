#!/bin/bash

count=0

while true; do
    read -p "x 입력(Enter=종료): " x
    [ -z "$x" ] && break

    y=$(echo "0.5 * $x * $x" | bc -l)
    echo "y = $y"

    count=$((count+1))
done

if [ $count -lt 2 ]; then
    echo "두 개 이상 입력해야 합니다."
fi

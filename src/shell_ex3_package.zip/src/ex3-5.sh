#!/bin/bash

run_cmd() {
    echo "실행: $*"
    eval "$*"
}

if [ $# -lt 1 ]; then
    echo "사용법: $0 <명령어> [옵션]"
    exit 1
fi

run_cmd "$@"

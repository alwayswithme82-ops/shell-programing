#!/bin/bash

DB=DB.txt
touch "$DB"

add_member() {
    read -p "이름: " n
    read -p "생일/전화번호: " info
    echo "MEMBER|$n|$info" >> "$DB"
}

add_log() {
    read -p "날짜(YYYY-MM-DD): " d
    read -p "팀원 이름: " n
    read -p "내용: " c
    echo "LOG|$d|$n|$c" >> "$DB"
}

search_member() {
    read -p "이름 검색: " n
    grep "^MEMBER|$n" "$DB"
}

search_date() {
    read -p "날짜 검색: " d
    grep "^LOG|$d" "$DB"
}

while true; do
cat <<EOF
1) 팀원 정보 추가
2) 수행 내용 기록
3) 팀원 검색
4) 날짜 검색
5) 종료
EOF

read -p "선택: " c

case $c in
    1) add_member ;;
    2) add_log ;;
    3) search_member ;;
    4) search_date ;;
    5) exit 0 ;;
    *) echo "1~5 입력" ;;
esac
done

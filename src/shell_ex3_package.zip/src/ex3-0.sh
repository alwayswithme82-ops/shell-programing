#!/bin/bash

BASHRC="$HOME/.bashrc"

grep -q 'export MYENV="Hello Shell"' "$BASHRC"
if [ $? -ne 0 ]; then
    echo 'export MYENV="Hello Shell"' >> "$BASHRC"
    echo "[+] MYENV 등록 완료"
else
    echo "[i] 이미 MYENV 가 등록되어 있음"
fi

source "$BASHRC"
echo "현재 MYENV 값: $MYENV"

echo "unset MYENV 를 실행하면 사라지는지 확인해보세요."

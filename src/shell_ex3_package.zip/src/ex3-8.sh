#!/bin/bash

mkdir -p DB train

cd DB
for i in {1..5}; do
    echo "file $i" > file$i.txt
done
tar -czf files.tar.gz file*.txt
cd ..

cd train
for i in {1..5}; do
    ln -sf ../DB/file$i.txt file$i.txt
done

echo "완료"

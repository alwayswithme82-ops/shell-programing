#!/bin/bash

user_info() {
    whoami
    id
}

cpu_gpu() {
    if command -v nvidia-smi >/dev/null; then
        nvidia-smi
    else
        top -b -n 1 | head -n 5
    fi
}

mem() { free -h; }
disk() { df -h; }

while true; do
cat <<EOF
1) 사용자 정보
2) CPU/GPU
3) 메모리
4) 디스크
5) 종료
EOF

read -p "선택: " c

case $c in
    1) user_info ;;
    2) cpu_gpu ;;
    3) mem ;;
    4) disk ;;
    5) exit 0 ;;
    *) echo "1~5 선택" ;;
esac
done

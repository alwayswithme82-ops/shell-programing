#!/bin/bash

scores=()

add_score() {
    read -p "점수(0~100): " s
    if [ $s -ge 0 ] && [ $s -le 100 ]; then
        scores+=("$s")
        echo "추가됨"
    else
        echo "잘못된 입력"
    fi
}

show_scores() {
    echo "--- 모든 점수 ---"
    for s in "${scores[@]}"; do
        echo "$s"
    done
}

avg_score() {
    sum=0
    for s in "${scores[@]}"; do
        sum=$((sum+s))
    done
    avg=$(echo "$sum / ${#scores[@]}" | bc -l)
    echo "평균 점수 = $avg"
}

gpa() {
    sum=0
    for s in "${scores[@]}"; do
        sum=$((sum+s))
    done
    avg=$(echo "$sum / ${#scores[@]}" | bc -l)

    if (( $(echo "$avg >= 90" | bc -l) )); then g=4.0
    elif (( $(echo "$avg >= 80" | bc -l) )); then g=3.0
    elif (( $(echo "$avg >= 70" | bc -l) )); then g=2.0
    elif (( $(echo "$avg >= 60" | bc -l) )); then g=1.0
    else g=0.0
    fi

    echo "평균 GPA = $g"
}

while true; do
cat <<EOF
1) 성적 추가
2) 모든 점수 보기
3) 평균 점수
4) 평균 GPA
5) 종료
EOF

read -p "선택: " c

case $c in
    1) add_score ;;
    2) show_scores ;;
    3) avg_score ;;
    4) gpa ;;
    5) exit 0 ;;
    *) echo "1~5 선택" ;;
esac
done

#!/bin/bash

read -p "과목 수(2 이상): " n
if [ $n -lt 2 ]; then
    echo "2개 이상 입력 필요"
    exit 1
fi

sum=0
for ((i=1; i<=n; i++)); do
    while true; do
        read -p "$i 번째 점수(0~100): " s
        if [ $s -ge 0 ] && [ $s -le 100 ]; then
            break
        fi
        echo "0~100 입력!"
    done

    if [ $s -ge 90 ]; then g="A"
    else g="B"
    fi
    echo "등급 = $g"

    sum=$((sum+s))
done

avg=$(echo "$sum/$n" | bc -l)

echo "평균 점수 = $avg"

if (( $(echo "$avg >= 90" | bc -l) )); then
    echo "평균 등급 = A"
else
    echo "평균 등급 = B"
fi

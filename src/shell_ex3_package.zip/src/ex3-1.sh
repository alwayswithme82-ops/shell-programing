#!/bin/bash

if [ $# -ne 2 ]; then
    echo "사용법: $0 <정수1> <정수2>"
    exit 1
fi

a=$1
b=$2

echo "$a + $b = $((a+b))"
echo "$a - $b = $((a-b))"
echo "$a * $b = $((a*b))"

if [ "$b" -eq 0 ]; then
    echo "0으로 나눌 수 없습니다."
else
    echo "$a / $b = $((a/b))"
fi
